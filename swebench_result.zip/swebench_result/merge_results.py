import ast
import json
import sys
import os
from pathlib import Path
import uuid
import subprocess
from datasets import load_dataset
from github import Github

# 全局加载数据集
ds = load_dataset("princeton-nlp/SWE-bench")
dataset = {item['instance_id']: item for item in ds['test']}
g = Github('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')

def check_syntax(code):
    if not code.strip():  # Check for cases where the model didn't return a python block
        return False
    try:
        ast.parse(code)
    except SyntaxError as e:
        print(f"SyntaxError: {e}")
        return False
    return True

_commit_file_cache = {}
def get_commit_file(repo, commit, file_path):
    """
    获取 commit 版本内 file_path 的文件内容，使用缓存提高性能
    
    Args:
        repo: GitHub 仓库对象
        commit: commit 对象
        file_path: 文件路径
        
    Returns:
        str: 文件内容
    """
    # 生成缓存键
    cache_key = f"{commit.sha}:{file_path}"
    
    # 检查缓存
    if cache_key in _commit_file_cache:
        print(f"\n从缓存获取文件 {file_path} 在 commit {commit.sha} 的内容")
        return _commit_file_cache[cache_key]
    
    print(f"\n获取文件 {file_path} 在 commit {commit.sha} 的内容")
    # 直接从 commit 对象获取文件内容
    file_content = repo.get_contents(file_path, ref=commit.sha)
    content = file_content.decoded_content.decode('utf-8')
    
    # 存入缓存
    _commit_file_cache[cache_key] = content
    
    return content

def fake_git_repo(repo_playground, file_path, old_content, new_content) -> str:
    """create a fake git repo to obtain git diff format"""
    # Generate a temperary folder and add uuid to avoid collision
    repo_playground = os.path.join(repo_playground, str(uuid.uuid4()))

    # assert playground doesn't exist
    assert not os.path.exists(repo_playground), f"{repo_playground} already exists"

    # create playground
    os.makedirs(repo_playground)

    # 处理文件路径，移除 ../ 前缀并确保使用相对路径
    normalized_path = os.path.normpath(file_path)
    if normalized_path.startswith('../'):
        normalized_path = normalized_path.replace('../', '', 1)
    
    # create a fake git repo
    subprocess.run(f"cd {repo_playground} && git init", shell=True)

    # create a file
    subprocess.run(
        f"mkdir -p {repo_playground}/{os.path.dirname(normalized_path)}", shell=True
    )

    with open(f"{repo_playground}/{normalized_path}", "w") as f:
        f.write(old_content)

    # add file to git
    subprocess.run(
        f"cd {repo_playground} && git add {normalized_path} && git commit -m 'initial commit'",
        shell=True,
    )

    # edit file
    with open(f"{repo_playground}/{normalized_path}", "w") as f:
        f.write(new_content)

    # get git diff
    o = subprocess.run(
        f"cd {repo_playground} && git diff {normalized_path}", shell=True, capture_output=True
    )

    s = o.stdout.decode("utf-8")

    # remove playground
    # subprocess.run(f"rm -rf {repo_playground}", shell=True)

    return s

def adjust_lines(text, indent_change):
    lines = text.splitlines()
    if indent_change < 0:
        # 减少缩进
        return '\n'.join(
            line[abs(indent_change):] if line.startswith(' ' * abs(indent_change)) else line 
            for line in lines
        )
    else:
        # 增加缩进
        return '\n'.join(' ' * indent_change + line for line in lines)

def create_patch(instance_id, buggy_code, fixed_code, file_path):
    # 获取完整的原始文件内容
    github_repo = g.get_repo(dataset[instance_id]['repo'])
    commit = github_repo.get_commit(dataset[instance_id]['base_commit'])
    original_content = get_commit_file(github_repo, commit, file_path)
    
    # 生成修复后的完整内容
    fixed_content = original_content.replace(buggy_code, fixed_code)
    # 计算原始代码和修复代码的缩进差异
    original_first_line = buggy_code.split('\n')[0]
    fixed_first_line = fixed_code.split('\n')[0]
    original_spaces = len(original_first_line) - len(original_first_line.lstrip())
    fixed_spaces = len(fixed_first_line) - len(fixed_first_line.lstrip())
    indent_diff = original_spaces - fixed_spaces  # 正数表示需要增加缩进，负数表示需要减少缩进
    indent_changes = [indent_diff, 0, -4, 4, -8, 8]  # 包含原始缩进(0)和其他缩进调整
    for indent_change in indent_changes:
        adjusted_code = adjust_lines(fixed_code, indent_change)
        fixed_content = original_content.replace(buggy_code, adjusted_code)
        # 检查新内容是否有效
        if check_syntax(fixed_content):
            break
    
    # 使用fake_git_apply生成新的文件内容
    git_diff = fake_git_repo("playground", file_path, original_content, fixed_content)
    
    print(f"Generated patch for {instance_id}:")
    return git_diff

def main():
    if len(sys.argv) != 2:
        print("Usage: python merge_results.py <id>")
        sys.exit(1)
        
    id_prefix = sys.argv[1]
    
    # 处理指定范围内的所有文件
    jsonl_path = f"results/{id_prefix}.jsonl"
        
    if not os.path.exists(jsonl_path):
        print(f"Warning: {jsonl_path} not found")
        continue
            
    with open(jsonl_path, 'r') as f:
            for line in f:
                item = json.loads(line)
                patch = create_patch(
                    item['instance_id'],
                    item['buggy_code'],
                    item['fixed_code'],
                    item['file_path']
                )
                with open(f"patches/{id_prefix}_{cnt}.jsonl", 'a') as f:
                    f.write(json.dumps({
                        'model_name_or_path': f'{id_prefix}_{cnt}',
                        'instance_id': item['instance_id'],
                        'model_patch': patch
                    }) + '\n')
if __name__ == "__main__":
    main()
