#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/pylint-dev/pylint /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 5e1928b325bc798f5be1ab94031bf6816d058d9f
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
apt-get update && apt-get install -y libenchant-2-dev hunspell-en-us
python -m pip install -e .
