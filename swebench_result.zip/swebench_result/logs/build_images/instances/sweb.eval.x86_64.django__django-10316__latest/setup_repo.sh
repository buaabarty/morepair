#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/django/django /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard cfb4845f061ed6e81e9b5a1873d1c08d98c4b5a9
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
apt-get update && apt-get install -y locales
echo 'en_US UTF-8' > /etc/locale.gen
locale-gen en_US.UTF-8
python setup.py install
