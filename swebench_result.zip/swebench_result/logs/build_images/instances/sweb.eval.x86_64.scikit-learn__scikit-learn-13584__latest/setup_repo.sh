#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/scikit-learn/scikit-learn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 0e3c1879b06d839171b7d0a607d71bbb19a966a9
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
