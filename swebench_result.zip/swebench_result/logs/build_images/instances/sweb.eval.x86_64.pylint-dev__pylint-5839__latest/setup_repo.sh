#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/pylint-dev/pylint /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 15040ee7c42958606ae27aa32ccbe54371b83049
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -e .
