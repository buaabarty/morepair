#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/django/django /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard a8bb49355698a5f7c7d25e06cad2571faa7af9a7
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
apt-get update && apt-get install -y locales
echo 'en_US UTF-8' > /etc/locale.gen
locale-gen en_US.UTF-8
python setup.py install
