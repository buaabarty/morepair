#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/mwaskom/seaborn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 60e58eb07e4448694ca25e887684d39d5138babd
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -e .[dev]
