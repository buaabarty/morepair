#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/scikit-learn/scikit-learn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard cd7d9d985e1bbe2dbbbae17da0e9fbbba7e8c8c6
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
