#!/bin/bash
set -euxo pipefail
source /opt/miniconda3/bin/activate
conda create -n testbed python=3.9 -y
cat <<'EOF_59812759871' > $HOME/requirements.txt
black==21.5b2;python_full_version>="3.6.2"
flake8==3.9.2
isort==5.8.0
mypy==0.812

astroid==2.5.8  # Pinned to a specific version for tests
pytest~=6.2
pytest-benchmark~=3.4

coveralls~=3.1
coverage~=5.5
pre-commit~=2.13;python_full_version>="3.6.2"
pyenchant~=3.2
pytest-cov~=2.12
pytest-profiling~=1.7
pytest-xdist~=2.2

EOF_59812759871
conda activate testbed && python -m pip install -r $HOME/requirements.txt
rm $HOME/requirements.txt
conda activate testbed
python -m pip install pyenchant==3.2
